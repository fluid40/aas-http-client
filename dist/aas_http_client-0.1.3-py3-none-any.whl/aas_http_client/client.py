"""BaSyx Server interface for REST API communication."""

import json
import logging
import re
import time
from pathlib import Path

import basyx.aas.adapter.json
import basyx.aas.adapter.json.json_serialization as js
import requests
from basyx.aas.model import AssetAdministrationShell, Reference, Submodel
from core.encoder import decode_base_64, encode_base_64
from pydantic import BaseModel, PrivateAttr, ValidationError
from requests import Session
from requests.auth import HTTPBasicAuth
from requests.models import Response

logger = logging.getLogger(__name__)

STATUS_CODE_200 = 200
STATUS_CODE_201 = 201
STATUS_CODE_202 = 202
STATUS_CODE_204 = 204
HEADERS = {"Content-Type": "application/json"}


def log_response_errors(response: Response):
    """Create error messages from the response and log them.

    :param response: response
    """
    result_error_messages: list[str] = []

    try:
        response_content_dict: dict = json.loads(response.content)

        if "detail" in response_content_dict:
            detail: dict = response_content_dict.get("detail", {})
            if "error" in detail:
                error: str = detail.get("error", "")
                result_error_messages.append(f"{error}")
            else:
                result_error_messages.append(f"{detail}")

        elif "messages" in response_content_dict or "Messages" in response_content_dict:
            messages: list = response_content_dict.get("messages", [])

            if not messages:
                messages = response_content_dict.get("Messages", [])

            for message in messages:
                if isinstance(message, dict) and "message" in message:
                    result_error_messages.append(message["message"])
                else:
                    result_error_messages.append(str(message))
        elif "error" in response_content_dict:
            result_error_messages.append(response_content_dict.get("error", ""))

    except json.JSONDecodeError:
        result_error_messages.append(response.content)

    logger.error(f"Status code: {response.status_code}")
    for result_error_message in result_error_messages:
        logger.error(result_error_message)


class AasxServerInterface(BaseModel):
    """Represents a AasxServerInterface to communicate with a REST API."""

    base_url: str = "http://basyx_aas_server:80/"
    username: str | None = None
    _password: str | None = PrivateAttr(default=None)
    https_proxy: str | None = None
    http_proxy: str | None = None
    time_out: int = 200
    connection_time_out: int = 100
    ssl_verify: bool = True
    _session: Session = PrivateAttr(default=None)
    namespace: str | None = None

    def initialize(self, password: str):
        """Initialize the AasxServerInterface with the given URL, username and password.

        :param password: password
        """
        self._password = password

        if self.base_url.endswith("/"):
            self.base_url = self.base_url[:-1]

        self._session = requests.Session()
        self._session.auth = HTTPBasicAuth(self.username, self._password)
        self._session.verify = self.ssl_verify

        if self.https_proxy:
            self._session.proxies.update({"https": self.https_proxy})
        if self.http_proxy:
            self._session.proxies.update({"http": self.http_proxy})

        if not self.namespace:
            self.namespace = re.sub(r":\d+", "", self.base_url)

    def _get_namespace(self) -> str:
        """Get the address of the REST API.

        :return: address as a string
        """
        match = re.search(r"^https?://([^:/]+)", self.base_url)

        if match:
            return match.group(1)

        raise ValueError(f"Invalid URL format: {self.base_url}")

    def get_root(self) -> dict | None:
        """Get the root of the REST API.

        :return: root data as a dictionary or None if an error occurred
        """
        url = f"{self.base_url}/shells"

        try:
            response = self._session.get(url, headers=HEADERS, timeout=2)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_200:
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        return json.loads(response.content)

    def post_shells(self, aas: AssetAdministrationShell) -> dict | None:
        """Post an Asset Administration Shell (AAS) to the REST API.

        :param aas: Asset Administration Shell to post
        :return: Response data as a dictionary or None if an error occurred
        """
        aas_dict_string = json.dumps(aas, cls=basyx.aas.adapter.json.AASToJsonEncoder)
        aas_dict = json.loads(aas_dict_string)

        url = f"{self.base_url}/shells"
        logger.debug(f"Call REST API url '{url}'")

        try:
            response = self._session.post(url, headers=HEADERS, json=aas_dict, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code not in (STATUS_CODE_201, STATUS_CODE_202):
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        content = json.loads(response.content)
        return dict(sorted(content.items()))

    def put_shells(self, identifier: str, aas: AssetAdministrationShell) -> bool:
        """Update an Asset Administration Shell (AAS) by its ID in the REST API.

        :param identifier: Identifier of the AAS to update
        :param aas: Asset Administration Shell data to update
        :return: True if the update was successful, False otherwise
        """
        aas_dict_string = json.dumps(aas, cls=basyx.aas.adapter.json.AASToJsonEncoder)
        aas_dict = json.loads(aas_dict_string)

        decoded_identifier: str = decode_base_64(identifier)
        url = f"{self.base_url}/shells/{decoded_identifier}"

        try:
            response = self._session.put(url, headers=HEADERS, json=aas_dict, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code is not STATUS_CODE_204:
                log_response_errors(response)
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return False

        return True

    def put_shells_submodels(self, aas_id: str, submodel_id: str, submodel: Submodel) -> bool:
        """Update a submodel by its ID for a specific Asset Administration Shell (AAS).

        :param aas_id: ID of the AAS to update the submodel for
        :param submodel: Submodel data to update
        :return: True if the update was successful, False otherwise
        """
        sm_dict_string = json.dumps(submodel, cls=basyx.aas.adapter.json.AASToJsonEncoder)
        sm_dict = json.loads(sm_dict_string)

        decoded_aas_id: str = decode_base_64(aas_id)
        decoded_submodel_id: str = decode_base_64(submodel_id)
        url = f"{self.base_url}/shells/{decoded_aas_id}/submodels/{decoded_submodel_id}"

        try:
            response = self._session.put(url, headers=HEADERS, json=sm_dict, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_204:
                log_response_errors(response)
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return False

        return True

    def get_shells(self) -> list[AssetAdministrationShell] | None:
        """Get all Asset Administration Shells (AAS) from the REST API.

        :return: AAS objects or None if an error occurred
        """
        url = f"{self.base_url}/shells"

        try:
            response = self._session.get(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_200:
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        content: list = json.loads(response.content)

        if not content:
            logger.warning("No AAS found in the REST API.")
            return []

        results: list = content.get("result", [])
        if not results:
            logger.warning("No AAS found in the REST API results.")
            return []

        aas_list: list[AssetAdministrationShell] = []

        for result in results:
            if not isinstance(result, dict):
                logger.error(f"Invalid AAS data: {result}")
                return None

            aas_dict_string = json.dumps(result)
            aas = json.loads(aas_dict_string, cls=basyx.aas.adapter.json.AASFromJsonDecoder)
            aas_list.append(aas)

        return aas_list

    def get_shells_by_id(self, aas_id: str) -> AssetAdministrationShell | None:
        """Get an Asset Administration Shell (AAS) by its ID from the REST API.

        :param aas_id: ID of the AAS to retrieve
        :return: AAS object or None if an error occurred
        """
        decoded_aas_id: str = decode_base_64(aas_id)
        url = f"{self.base_url}/shells/{decoded_aas_id}"

        try:
            response = self._session.get(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_200:
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        aas_dict_string = response.content.decode("utf-8")
        return json.loads(aas_dict_string, cls=basyx.aas.adapter.json.AASFromJsonDecoder)

    def get_shells_reference_by_id(self, aas_id: str) -> Reference | None:
        decoded_aas_id: str = decode_base_64(aas_id)
        url = f"{self.base_url}/shells/{decoded_aas_id}/$reference"

        try:
            response = self._session.get(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_200:
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        ref_dict_string = response.content.decode("utf-8")
        return json.loads(ref_dict_string, cls=basyx.aas.adapter.json.AASFromJsonDecoder)

    def get_shells_submodels(self, aas_id: str, submodel_id: str) -> Submodel | None:
        """Get a submodel by its ID for a specific Asset Administration Shell (AAS).

        :param aas_id: ID of the AAS to retrieve the submodel from
        :param submodel_id: ID of the submodel to retrieve
        :return: Submodel object or None if an error occurred
        """
        decoded_aas_id: str = decode_base_64(aas_id)
        decoded_submodel_id: str = decode_base_64(submodel_id)

        url = f"{self.base_url}/shells/{decoded_aas_id}/submodels/{decoded_submodel_id}"

        try:
            response = self._session.get(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_200:
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        submodel_dict_string = response.content.decode("utf-8")
        return json.loads(submodel_dict_string, cls=basyx.aas.adapter.json.AASFromJsonDecoder)

    def delete_shells_by_id(self, aas_id: str) -> bool:
        """Get an Asset Administration Shell (AAS) by its ID from the REST API.

        :param aas_id: ID of the AAS to retrieve
        :return: True if the deletion was successful, False otherwise
        """
        decoded_aas_id: str = decode_base_64(aas_id)
        url = f"{self.base_url}/shells/{decoded_aas_id}"

        try:
            response = self._session.delete(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_204:
                log_response_errors(response)
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return False

        return True

    def post_submodels(self, submodel: Submodel) -> bool:
        """Post a submodel to the REST API.

        :param submodel: submodel data as a dictionary
        :return: Response data as a dictionary or None if an error occurred
        """
        sm_dict_string = json.dumps(submodel, cls=basyx.aas.adapter.json.AASToJsonEncoder)
        sm_dict = json.loads(sm_dict_string)

        url = f"{self.base_url}/submodels"

        try:
            response = self._session.post(url, headers=HEADERS, json=sm_dict, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code not in (STATUS_CODE_201, STATUS_CODE_202):
                log_response_errors(response)
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return False

        return True

    def put_submodels(self, identifier: str, submodel: Submodel) -> bool:
        """Update a submodel by its ID in the REST API.

        :param identifier: Identifier of the submodel to update
        :param submodel: Submodel data to update
        :return: True if the update was successful, False otherwise
        """
        sm_dict_string = json.dumps(submodel, cls=basyx.aas.adapter.json.AASToJsonEncoder)
        sm_dict = json.loads(sm_dict_string)

        decoded_identifier: str = decode_base_64(identifier)
        url = f"{self.base_url}/submodels/{decoded_identifier}"

        try:
            response = self._session.put(url, headers=HEADERS, json=sm_dict, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_204:
                log_response_errors(response)
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return False

        return True

    def get_submodel_by_id(self, submodel_id: str) -> Submodel | None:
        """Get a submodel by its ID from the REST API.

        :param submodel_id: ID of the submodel to retrieve
        :return: Submodel object or None if an error occurred
        """
        decoded_submodel_id: str = decode_base_64(submodel_id)
        url = f"{self.base_url}/submodels/{decoded_submodel_id}"

        try:
            response = self._session.get(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_200:
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        sm_dict_string = response.content.decode("utf-8")
        return json.loads(sm_dict_string, cls=basyx.aas.adapter.json.AASFromJsonDecoder)

    def get_submodels(self) -> list[Submodel] | None:
        """Get all submodels from the REST API.

        :return: Submodel objects or None if an error occurred
        """
        url = f"{self.base_url}/submodels"

        try:
            response = self._session.get(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_200:
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        content: list = json.loads(response.content)

        if not content:
            logger.warning("No submodels found in the REST API.")
            return []

        results: list = content.get("result", [])
        if not results:
            logger.warning("No submodels found in the REST API results.")
            return []

        submodels: list[Submodel] = []

        for result in results:
            if not isinstance(result, dict):
                logger.error(f"Invalid submodel data: {result}")
                return None

            sm_dict_string = json.dumps(result)
            submodel = json.loads(sm_dict_string, cls=basyx.aas.adapter.json.AASFromJsonDecoder)
            submodels.append(submodel)

        return submodels

    def get_submodels_by_id(self, submodel_id: str) -> Submodel | None:
        """Get a submodel by its ID from the REST API.

        :param submodel_id: ID of the submodel to retrieve
        :return: Submodel object or None if an error occurred
        """
        decoded_submodel_id: str = decode_base_64(submodel_id)
        url = f"{self.base_url}/submodels/{decoded_submodel_id}"

        try:
            response = self._session.get(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_200:
                log_response_errors(response)
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return None

        sm_dict_string = response.content.decode("utf-8")
        return json.loads(sm_dict_string, cls=basyx.aas.adapter.json.AASFromJsonDecoder)

    def patch_submodel_by_id(self, submodel_id: str, submodel: Submodel):
        sm_dict_string = json.dumps(submodel, cls=basyx.aas.adapter.json.AASToJsonEncoder)
        sm_dict = json.loads(sm_dict_string)

        decoded_submodel_id: str = decode_base_64(submodel_id)
        url = f"{self.base_url}/submodels/{decoded_submodel_id}"

        try:
            response = self._session.patch(url, headers=HEADERS, json=sm_dict, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_204:
                log_response_errors(response)
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return False

        return True

    def delete_submodels_by_id(self, submodel_id: str) -> bool:
        """Delete a submodel by its ID from the REST API.

        :param submodel_id: ID of the submodel to delete
        :return: True if the deletion was successful, False otherwise
        """
        decoded_submodel_id: str = decode_base_64(submodel_id)
        url = f"{self.base_url}/submodels/{decoded_submodel_id}"

        try:
            response = self._session.delete(url, headers=HEADERS, timeout=self.time_out)
            logger.debug(f"Call REST API url '{response.url}'")

            if response.status_code != STATUS_CODE_204:
                log_response_errors(response)
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"Error call REST API: {e}")
            return False

        return True


def create_client_by_url(
    base_url: str,
    username: str = "",
    password: str = "",
    http_proxy: str = "",
    https_proxy: str = "",
    time_out: int = 200,
    connection_time_out: int = 60,
    ssl_verify: str = True,  # noqa: FBT002
    namespace: str = "",
) -> AasxServerInterface | None:
    """Create a BaSyx server interface client from the given parameters.

    :param base_url: base URL of the BaSyx server, e.g. "http://basyx_python_server:80/"_
    :param username: username for the BaSyx server interface client, defaults to ""_
    :param password: password for the BaSyx server interface client, defaults to ""_
    :param http_proxy: http proxy URL, defaults to ""_
    :param https_proxy: https proxy URL, defaults to ""_
    :param time_out: timeout for the API calls, defaults to 200
    :param connection_time_out: timeout for the connection to the API, defaults to 60
    :param ssl_verify: whether to verify SSL certificates, defaults to True
    :return: An instance of AasxServerInterface initialized with the provided parameters.
    """
    logger.info(f"Create BaSyx server interface client from URL '{base_url}'")
    config_dict: dict[str, str] = {}
    config_dict["base_url"] = base_url
    config_dict["username"] = username
    config_dict["http_proxy"] = http_proxy
    config_dict["https_proxy"] = https_proxy
    config_dict["time_out"] = time_out
    config_dict["connection_time_out"] = connection_time_out
    config_dict["ssl_verify"] = ssl_verify
    config_dict["namespace"] = namespace
    config_string = json.dumps(config_dict, indent=4)
    return _create_client(config_string, password)


def create_client_by_config(config_file: Path, password: str = "") -> AasxServerInterface | None:
    """Create a BaSyx server interface client from the given parameters.

    :param config_file: Path to the configuration file containing the BaSyx server connection settings.
    :param password: password for the BaSyx server interface client, defaults to ""_
    :return: An instance of AasxServerInterface initialized with the provided parameters.
    """
    logger.info(f"Create BaSyx server interface client from config file '{config_file}'")
    if not config_file.exists():
        config_string = "{}"
        logger.warning(f"Server config file '{config_file}' not found. Using default config.")
    else:
        config_string = config_file.read_text(encoding="utf-8")
        logger.debug(f"Server config  file '{config_file}' found.")

    return _create_client(config_string, password)


def _create_client(config_string: str, password) -> AasxServerInterface | None:
    try:
        connection_settings = AasxServerInterface.model_validate_json(config_string)
        client = AasxServerInterface(**connection_settings.model_dump())
    except ValidationError as ve:
        raise ValidationError(f"Invalid BaSyx server connection file: {ve}") from ve

    logger.info(
        f"Using server configuration: '{client.base_url}' | "
        f"timeout: '{client.time_out}' | "
        f"username: '{client.username}' | "
        f"https_proxy: '{client.https_proxy}' | "
        f"http_proxy: '{client.http_proxy}' | "
        f"connection_timeout: '{client.connection_time_out}'"
    )
    client.initialize(password)

    # test the connection to the REST API
    connected = _connect_to_api(client)

    if not connected:
        return None

    return client


def _connect_to_api(client: AasxServerInterface) -> bool:
    start_time = time.time()
    logger.debug(f"Try to connect to REST API '{client.base_url}' for {client.connection_time_out} seconds")
    counter: int = 0
    while True:
        try:
            root = client.get_root()
            if root:
                logger.info(f"Connected to REST API at '{client.base_url}' successfully.")
                return True
        except requests.exceptions.ConnectionError:
            pass
        if time.time() - start_time > client.connection_time_out:
            raise TimeoutError(f"Connection to REST API timed out after {client.connection_time_out} seconds.")

        counter += 1
        logger.warning(f"Retrying connection (attempt: {counter})")
        time.sleep(1)
